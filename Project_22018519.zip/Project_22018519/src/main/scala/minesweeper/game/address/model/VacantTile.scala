package minesweeper.game.address.model

class VacantTile(var symbol: String = "") extends Tile("empty") {

}
